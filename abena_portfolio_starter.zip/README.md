# Abena Afriyie Adasi Portfolio

Welcome to my GIS, Data Analytics, and Spatial Data Science portfolio.

## Sections
- About
- Skills
- Projects
- Contact

Each project folder contains data, notebooks, outputs, and documentation.
