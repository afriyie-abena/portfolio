# 06 Landuse Change Kumasi

## Objective
Describe the aim of this project.

## Data
List sources of data used.

## Tools
Mention software/libraries used.

## Steps
1. Step one
2. Step two

## Outputs
- Map, dashboard, or chart

## What I Learned
Summarize key skills gained.
